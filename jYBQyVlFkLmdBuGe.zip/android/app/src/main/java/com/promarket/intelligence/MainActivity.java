package com.promarket.intelligence;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
