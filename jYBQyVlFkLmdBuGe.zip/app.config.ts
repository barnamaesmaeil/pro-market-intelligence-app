export default {
  logoUrl:
    "https://files.manuscdn.com/user_upload_by_module/session_file/310519663999697959/TOUVuxBnfQChBuxi.svg",
};
